package com.geniusgithub.mediarender;

public class DeviceInfo {

	public String dev_name;
	public String uuid;
	public boolean status;
	
	public DeviceInfo(){
		dev_name = "";
		uuid = "";
		status = false;
	}
}
