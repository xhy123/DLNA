package com.geniusgithub.mediarender.music.lrc;

public class LyricObject {
	public int begintime; // Begin time
	public int endtime; // End time
	public int timeline; // Time of single line
	public String lrc; // Lyrics of single line
}
