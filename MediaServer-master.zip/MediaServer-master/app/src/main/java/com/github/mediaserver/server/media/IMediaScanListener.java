package com.github.mediaserver.server.media;

public interface IMediaScanListener {

	public void mediaScan(int mediaType, String mediaPath, String mediaName);
}
